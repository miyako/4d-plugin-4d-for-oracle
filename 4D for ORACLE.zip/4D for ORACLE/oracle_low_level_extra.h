#ifndef __ORACLE_LOW_LEVEL_EXTRA_H__
#define __ORACLE_LOW_LEVEL_EXTRA_H__ 1

#include "4DPluginAPI.h"
#include "4DPlugin.h"

void OD_INTROSPECT_CURSOR(sLONG_PTR *pResult, PackagePtr pParams);

#endif